# Fundación Legis — sitio estático (ES/EN)

Este repositorio contiene el sitio listo para publicar en **GitHub Pages**.

## Publicación rápida (Project Pages)
1. Crea un repositorio (privado o público), por ejemplo `fundacion-legis`.
2. Sube todos los archivos de esta carpeta a la raíz del repo (incluido `.nojekyll`).
3. En **Settings → Pages** selecciona *Deploy from branch* y la rama `main` en `/ (root)`.
4. Pulsa **Save**. En 1–2 minutos tendrás la web en:
   `https://<tu-usuario>.github.io/fundacion-legis/`

> Si vas a usar **User/Org Pages** (repo `tu-usuario.github.io`), también funciona sin cambios.

## Estructura
- `index.html` (ES) y `en/index.html` (EN)
- Páginas legales: `legal.html`, `privacy.html`, `cookies.html`
- Noticias: `blog.html` (ES) y `en/news.html` (EN)
- Recursos: `assets/css`, `assets/js`, `assets/img`
- SEO: `sitemap.xml`, `robots.txt`
- Accesibilidad: WCAG AA, navegación teclado, diálogo cookies accesible
- Banner de cookies: preferencias persistentes (localStorage)

## Personalización
- Edita teléfonos/NIF/dirección en `index.html` y `en/index.html`.
- Añade noticias en `blog.html` y `en/news.html`.
- Modifica colores/estilos en `assets/css/styles.css`.
- Activa analítica respetando consentimiento en `assets/js/main.js`.

© 2025 Fundación Legis. Sitio desarrollado por Elena Ordiales.
